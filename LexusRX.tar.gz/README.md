# Lexus RX 450 Model

Place this file in AutowareAuto/src/urdf/lexus_rx_450h_description/meshes/

Source: https://gitlab.com/autowarefoundation/autoware.auto/AutowareAuto/-/tree/master/src/urdf/lexus_rx_450h_description/meshes

